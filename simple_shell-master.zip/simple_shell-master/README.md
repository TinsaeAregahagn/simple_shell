shellby - Simple Shell 🐚
A simple UNIX command interpreter written as part of the low-level programming and algorithm track.
